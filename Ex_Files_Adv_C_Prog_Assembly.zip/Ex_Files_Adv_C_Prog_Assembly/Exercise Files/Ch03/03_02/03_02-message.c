#include <stdio.h>

void message(void)
{
	puts("Here I am, stuck in a loop!");
}
