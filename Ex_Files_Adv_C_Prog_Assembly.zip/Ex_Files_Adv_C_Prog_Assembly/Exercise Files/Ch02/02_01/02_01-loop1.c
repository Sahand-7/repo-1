int main()
{
	register int x = 0;

	while(x<100)
		x++;

	return 0;
}
